//var scrape = require('./website-scraper/index.js');
var scrape = require('website-scraper');

scrape({
  urls: ['http://localhost:8080/index.html'],
  directory: './eao-articles',
  sources: [
    {selector: 'img', attr: 'src'},
    {selector: 'link[rel="stylesheet"]', attr: 'href'}
  ],
  onResourceSaved: (resource) => {
  	console.log(`Resource ${resource} was saved to fs`);
  },
  onResourceError: (resource, err) => {
  	console.log(`Resource ${resource} was not saved because of ${err}`);
  },
  recursive: true,
  maxRecursiveDepth: 3,
  maxDepth: 5,
  filenameGenerator: 'bySiteStructure',
}).then(console.log).catch(console.log);

