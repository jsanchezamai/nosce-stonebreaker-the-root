var elem = document.createElement('script');
elem.src = 'https://quantcast.mgr.consensu.org/v26/cmp.js';
elem.async = true;
elem.type = "text/javascript";

var scpt = document.getElementsByTagName('script')[0];
scpt.parentNode.insertBefore(elem, scpt);

(function() {
    var gdprAppliesGlobally = true;
    function addFrame() {
        if (!window.frames['__cmpLocator']) {
            if (document.body) {
                var body = document.body,
                iframe = document.createElement('iframe');
                iframe.style = 'display:none';
                iframe.name = '__cmpLocator';
                body.appendChild(iframe);
            } else {
                setTimeout(addFrame, 5);
            }
        }
    }

    addFrame();

    function cmpMsgHandler(event) {
        var msgIsString = typeof event.data === "string";
        var json;

        if(msgIsString) {
            json = event.data.indexOf("__cmpCall") != -1 ? JSON.parse(event.data) : {};
        } else {
            json = event.data;
        }

        if (json.__cmpCall) {
            var i = json.__cmpCall;
            window.__cmp(i.command, i.parameter, function(retValue, success) {
                var returnMsg = {"__cmpReturn": {
                    "returnValue": retValue,
                    "success": success,
                    "callId": i.callId
                }};
            
            event.source.postMessage(msgIsString ?
                JSON.stringify(returnMsg) : returnMsg, '*');
            });
        }

    }

    checkAd = setInterval(() => {
        var link_quantcast = document.getElementsByClassName("qc-cmp-qc-link-container");
        if(link_quantcast[0]) {
            link_quantcast[0].parentNode.removeChild(link_quantcast[0]);
            clearInterval(checkAd);
        }
    }, 300);

    move_confAd = setInterval(() => {

        if(document.getElementsByClassName("qc-cmp-persistent-link")[0]) {   
            var conf_ad = document.getElementsByClassName("qc-cmp-persistent-link")[0];
                conf_ad.removeAttribute("style");

            if(conf_ad.parentElement.parentElement.getAttribute("id") != "legalise") {

                var li_el = document.createElement("li");
                    li_el.classList.add("cmp");

                t = document.createTextNode(" / ");

                li_el.appendChild(t);
                li_el.appendChild(conf_ad);

                if(document.getElementById('legalese'))
                document.getElementById('legalese').appendChild(li_el);
                
                clearInterval(move_confAd);
            }
        }

    }, 300);

    window.__cmp = function (c) {
        
        var b = arguments;
        if (!b.length) {
            return __cmp.a;
        }
        else if (b[0] === 'ping') {
            b[2]({"gdprAppliesGlobally": gdprAppliesGlobally,
            "cmpLoaded": false}, true);
        } else if (c == '__cmp')
            return false;
        else {
            if (typeof __cmp.a === 'undefined') {
                __cmp.a = [];
            }
        __cmp.a.push([].slice.apply(b));
        }
    }

    window.__cmp.gdprAppliesGlobally = gdprAppliesGlobally;
    window.__cmp.msgHandler = cmpMsgHandler;
    if (window.addEventListener) {
        window.addEventListener('message', cmpMsgHandler, false);
    } else {
        window.attachEvent('onmessage', cmpMsgHandler);
    }

})();

window.__cmp('init', {
    'Language': 'es',
    'Initial Screen Title Text': 'Nos obligan a molestarte con la obviedad de que este sitio utiliza cookies',
    'Initial Screen Reject Button Text': 'No acepto',
    'Initial Screen Accept Button Text': 'Acepto',
    'Initial Screen Purpose Link Text': 'M&aacutes informaci&oacuten',
    'Purpose Screen Title Text': 'Tu privacidad es importante para nosotros',
    'Purpose Screen Header Title Text': 'Configuraci&oacuten de privacidad',
    'Purpose Screen Body Text': 'Puedes configurar tus preferencias y elegir como quieres que tus datos sean utilizados para los siguientes prop&oacutesitos. Puedes elegir configurar tus preferencias solo con nosotros independientemente del resto de nuestros partners. Cada prop&oacutesito tiene una descripci&oacuten para que puedas saber como nosotros y nuestros partners utilizamos tus datos',
    'Purpose Screen Enable All Button Text': 'Habilitar todo',
    'Purpose Screen Vendor Link Text': 'Ver lista completa de partners',
    'Purpose Screen Cancel Button Text': 'Cancelar',
    'Purpose Screen Save and Exit Button Text': 'Guardar y salir',
    'Vendor Screen Title Text': 'Tu privacidad es importante para nosotros',
    'Vendor Screen Body Text': 'Puedes dar tu consentimiento de manera individual a cada partner. Ver la lista de todos los prop&oacutesitos para los cuales utilizan tus datos para tener m&aacutes informaci&oacuten. En algunos casos, las empresas pueden revelar que usan tus datos sin pedir tu consentimiento, en funci&oacuten de intereses leg&iacutetimos. Puedes hacer click en su pol&iacutetica de privacidad para obtener m&aacutes informaci&oacuten al respecto o para rechazarlo.',
    'Vendor Screen Accept All Button Text': 'Aceptar todo',
    'Vendor Screen Reject All Button Text': 'Rechazar todo',
    'Vendor Screen Purposes Link Text': 'Ver porop&oacutesitos',
    'Vendor Screen Cancel Button Text': 'Cancelar',
    'Vendor Screen Save and Exit Button Text': 'Guardar y salir',
    'Initial Screen Body Text': 'Menéame y otros servicios que integra Menéame utiliza cookies para analizar el tráfico, personalizar publicidad y contenido y proporcionar algunas funcionalidades. Haciendo click consientes el uso de esta tecnología en nuestra web. Desactivando alguna de las opciones pierdes la autoridad moral de quejarte de Menéame.',
    'Initial Screen Body Text Option': 2,
    'Publisher Name': 'Menéame',
    'Publisher Purpose IDs': [1,2,3,4,5],
    'UI Layout': 'banner',
    'No Option': false,
    'Consent Scope': 'service',
    'Default Value for Toggles': 'on',
});
