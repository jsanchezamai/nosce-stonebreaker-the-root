$(document).ready(function() {
    var readURL = function(input) {

        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                var image = new Image();
                image.src = e.target.result;
                image.onload = function () {
                    var profilePicCss = $('.profile-pic');
                    if (this.width < this.height) {
                        profilePicCss.css('height', '');
                        profilePicCss.css('max-height', '');
                        profilePicCss.css('width', '100%');
                        profilePicCss.css('max-width', '100%');
                    } else {
                        profilePicCss.css('height', '100%');
                        profilePicCss.css('max-height', '100%');
                        profilePicCss.css('width', '');
                        profilePicCss.css('max-width', '');
                    }
                };

                $('#user-avatar').attr('src', e.target.result).removeClass('hidden');
                $('#default-avatar').addClass('hidden');
                showRemoveAvatarButton();
            };

            reader.readAsDataURL(input.files[0]);
        }
    };

    var showRemoveAvatarButton =  function() {
        var userAvatar = $('#user-avatar');
        var defaultAvatar = $('#default-avatar');

        if (userAvatar.length !== 0 && defaultAvatar.length !== 0) {
            if (userAvatar.attr('src') === defaultAvatar.attr('src')) {
                $('#remove-avatar').addClass('invisible');
            } else {
                $('#remove-avatar').removeClass('invisible').find('input:checkbox').prop('checked', false);
            }
        }

    };

    var onClickRemoveAvatar = function (e) {
        $('#user-avatar').addClass('hidden').attr('src', null);
        $('.file-upload').val(null);

        $('#default-avatar').removeClass('hidden');
        $('#remove-avatar').addClass('invisible').find('input:checkbox').prop('checked', true);

        return false;
    };

    var init = function() {
        $(".file-upload").on('change', function(){
            readURL(this);
        });

        $(".upload-button").on('click', function() {
            $(".file-upload").click();
        });

        $("#remove-avatar").on('click', onClickRemoveAvatar);

        showRemoveAvatarButton();
    };

    init();
});